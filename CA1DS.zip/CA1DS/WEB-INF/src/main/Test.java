package main;

import java.util.ArrayList;
import java.util.List;

import dao.LoanDepositDao;
import dao.LoanDao;
import dao.CustomerDao;
import entities.Customer;
import entities.Loan;
import entities.LoanDeposit;

public class Test {
	
	
	public Test() {
		CustomerDao cDAO = new CustomerDao();
		LoanDao lDAO = new LoanDao();
		LoanDepositDao dDAO = new LoanDepositDao();
		
		//Add LoanDeposit
		LoanDeposit d1 = new LoanDeposit("100","10/01/2023");
		LoanDeposit d2 = new LoanDeposit("68" ,"3/7/2022");
		LoanDeposit d3 = new LoanDeposit("25","4/8/2021");
		dDAO.persist(d1);
		dDAO.persist(d2);
		dDAO.persist(d3);
		
		List<LoanDeposit> LoanDeposit = new ArrayList<LoanDeposit>();
		LoanDeposit.add(d1);
		LoanDeposit.add(d2);
		LoanDeposit.add(d3);
		//Add Loan
		Loan loan= new Loan("StudentLoan", LoanDeposit);
		lDAO.persist(loan);
		
		///Add Customer
		Customer customer = new Customer("Afeez" ,"081222","1 The Lawn","100", loan );
		cDAO.persist(customer);
		
		
		//View all subscribers (here I've accessed all objects through the subscriber)
		ArrayList<Customer> customers = (ArrayList<Customer>) cDAO.getAllCustomers();
		for(Customer c : customers) {
			System.out.println("Customer object namesl is "+c.getName());
			System.out.println("Customer Loan is "+ c.getLoan().getDescription());
			//Note I've made an Eagar Fetch on the Comments List in Profile to enable this
			System.out.println("Customers loan first comment is "+c.getLoan().getLoanDeposit().get(0).getDepositAmount());
		}
		
		//Update username using merge
		customer.setName("STEVO");
		cDAO.merge(customer);	
		
		//remove the last comment
		dDAO.remove(d3);
		
		//Get subscriber by username, print their password
		System.out.println(cDAO.getCustomerByUsername("STEVO").getName());
		
	}
	
	public static void main(String[] args) {
		new Test();
	}

}
