package dao;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import dao.LoanDepositDao;
import entities.Customer;
import entities.LoanDeposit;
@Path("/LoanDepositSerDAO")
public class LoanDepositSerDAO {
	
	private static Map<String, LoanDeposit> loanDeposits = new HashMap<String, LoanDeposit>();
	
	static {
		
	       LoanDeposit loanDeposit1 = new LoanDeposit();
	       loanDeposit1.setId(1);
	       loanDeposit1.setDepositAmount("1000");
	       loanDeposit1.setDepositDate("10/01/4567");
	       loanDeposits.put(loanDeposit1.getDepositAmount(), loanDeposit1);
        
	       LoanDeposit loanDeposit2 = new LoanDeposit();
	       loanDeposit2.setId(1);
	       loanDeposit2.setDepositAmount("888");
	       loanDeposit2.setDepositDate("3/10/3456");
	       loanDeposits.put(loanDeposit1.getDepositAmount(), loanDeposit2);
    }

	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }
	
	@GET
    @Path("/helloworld")
    @Produces("text/plain")
    public String helloWorld(){
        return "Hello World New";    
    }
	
	
	@GET
    @Path("/echo/{message}")
    @Produces("text/plain")
    public String echo(@PathParam("message")String message){
        return message;  
    }
	
	
	@GET
    @Path("/employees")
    @Produces("application/xml")
    public List<LoanDeposit> listEmployees(){
        return new ArrayList<LoanDeposit>(loanDeposits.values());
    }
	
	@GET
    @Path("/employee/{loanDepositid}")
    @Produces("application/xml")
    public LoanDeposit getEmployee(@PathParam("loanDepositid")String loanDepositid){
		return loanDeposits.get(loanDepositid);		
    }
	
	@POST
	@Path("/createxml")
    @Consumes("application/xml")
    public String addEmployee(LoanDeposit loanDeposits) {
		return "Deposit Amount " +loanDeposits.getDepositAmount();		
    }
	
	@POST
	@Path("/createjson")
    @Consumes("application/json")
    public String addJSONEmployee(LoanDeposit loanDeposits){
		return "Deposit Amount " +loanDeposits.getDepositAmount();		
    }
	
	@GET
    @Path("/json/employees/")
    @Produces("application/json")
    public List<LoanDeposit> listLoanDepositJSON(){
		return new ArrayList<LoanDeposit>(loanDeposits.values());
    }

	@GET
    @Path("/json/employee/{employeeid}")
    @Produces("application/json")
    public LoanDeposit getLoanDepositJSON(@PathParam("loanDepositid")String loanDepositid){
		return loanDeposits.get(loanDepositid);		
    }
	

}


