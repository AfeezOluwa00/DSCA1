package dao;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;


import dao.LoanDepositDao;
import entities.LoanDeposit;



@Path("/LoanDepositServDAODBCRUD")
public class LoanDepositServDAODBCRUD {
	
		private static Map<String, LoanDeposit> loanDeposits = new HashMap<String, LoanDeposit>();
		
		static {
			
			LoanDeposit loanDeposit1 = new LoanDeposit();
			loanDeposit1.setId(1);
			loanDeposit1.setDepositAmount("123");
			loanDeposit1.setDepositDate("10/4/2022");
	        loanDeposits.put(loanDeposit1.getDepositAmount(), loanDeposit1);
	        
	        LoanDeposit loanDeposit2 = new LoanDeposit();
			loanDeposit2.setId(1);
			loanDeposit2.setDepositAmount("888");
			loanDeposit2.setDepositDate("11/11/2222");
	        loanDeposits.put(loanDeposit1.getDepositAmount(), loanDeposit1);
	        
	    }


	@GET
   @Path("/hello")
   @Produces("text/plain")
   public String hello(){
       return "Hello World";    
   }
	
	@GET
   @Path("/helloworld")
   @Produces("text/plain")
   public String helloWorld(){
       return "Hello World New";    
   }
	
	@GET
   @Path("/echo/{message}")
   @Produces("text/plain")
   public String echo(@PathParam("message")String message){
       return message;  
   }
	
	@GET
   @Path("/newEcho/{message}")
   @Produces("text/plain")
   public String newEcho(@PathParam("message")String message){
       return message;  
   }

	
	@GET
   @Path("/loanDeposits")
   @Produces("application/xml")
   public List<LoanDeposit> listLoanDeposit(){
       return new ArrayList<LoanDeposit>(loanDeposits.values());
   }
	
	@GET
   @Path("/loanDeposit/{loanDepositid}")
   @Produces("application/xml")
   public LoanDeposit getLoanDeposit(@PathParam("loanDepositid")String loanDepositid){
		return loanDeposits.get(loanDepositid);
	}
   
	
	@POST
	@Path("/createxml")
   @Consumes("application/xml")
   public String addLoanDeposit(LoanDeposit loanDeposits){
		
		return "Loan Deposit added " +loanDeposits.getDepositAmount();		
   }
	
	@POST
	@Path("/createjson")
   @Consumes("application/json")
   public String addJSONLoanDeposit(LoanDeposit loanDeposits){
		return "Loan Deposit added " +loanDeposits.getDepositAmount();		
   }
	
	@GET
   @Path("/json/loanDeposits/")
   @Produces("application/json")
   public List<LoanDeposit> listLoanDepositsJSON(){
		return new ArrayList<LoanDeposit>(loanDeposits.values());
   }

	@GET
   @Path("/json/loanDeposit/{loanDepositid}")
   @Produces("application/json")
   public LoanDeposit getLoanDepositJSON(@PathParam("loanDepositid")String loanDepositid){
		return loanDeposits.get(loanDepositid);		
   }
	
	@GET
   @Path("/loanDepositsxmlfromdb")
   @Produces("application/xml")
   public List<LoanDeposit> getLoanDepositFromDB(){
		LoanDepositDao dao = new LoanDepositDao();
       return dao.getAllLoanDeposits();
   }
	
	@GET
   @Path("/loanDepositsjsonfromdb")
   @Produces("application/json")
   public List<LoanDeposit> getJSONLoanDepositFromDB(){
		LoanDepositDao dao = new LoanDepositDao();
       return dao.getAllLoanDeposits();
   }
	

	@GET
    @Path("/jsonDB/loanDeposit/{loanDepositID}")
    @Produces("application/json")
    public LoanDeposit getLoanDepositIDFromDBJSON(@PathParam("employeeName")String LoanID){
		LoanDepositDao dao = new LoanDepositDao();
		return dao.getLoanDepositByID(LoanID);		
    }
	
	@GET
   @Path("/loanDepositfromDBXML/{LoanDepositID}")
   @Produces("application/xml")
   public LoanDeposit getLoanDepositByIDFromDBXML(@PathParam("Loan ID")String LoanID){
		LoanDepositDao dao = new LoanDepositDao();
		return dao.getLoanDepositByID(LoanID);	
   }
	
	@POST
	@Path("/newLoanDeposit")
   @Consumes("application/json")
   public String addLoanDepositsToDBJSON(LoanDeposit loanDeposits){
		LoanDepositDao dao = new LoanDepositDao();
		dao.persist(loanDeposits);
		return "Loan Deposit added to DB from JSON Param "+loanDeposits.getId();	
   }
	
	@PUT
   @Path("/updateLoanDeposit/")
   @Produces("application/json")
   public LoanDeposit updateLoanDeposit(LoanDeposit loanDeposits){
		LoanDepositDao dao = new LoanDepositDao();
		return dao.merge(loanDeposits);	
   }
	
	@DELETE
   @Path("/deleteLoanDeposit/{LoanName}")
   @Produces("text/plain")
   public String deleteLoanDeposit(@PathParam("LoanName")String LoanName){
		LoanDepositDao dao = new LoanDepositDao();
		LoanDeposit cus = dao.getLoanDepositByID(LoanName);
		dao.remove(cus);	
		return "LoanDeposit "+cus+" deleted";
   }
	
	
}

