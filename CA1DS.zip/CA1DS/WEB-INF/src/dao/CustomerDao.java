package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.Customer;


public class CustomerDao {
	
	protected static EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("AfeezPu"); 	
	
	public CustomerDao() {
		
	}
	
	public void persist(Customer customer) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
		em.close();
	}
	
	public void remove(Customer customer) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(customer));
		em.getTransaction().commit();
		em.close();
	}
	
	public Customer merge(Customer customer) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Customer updatedCustomer= em.merge(customer);
		em.getTransaction().commit();
		em.close();
		return updatedCustomer;
	}
	
	
	public List<Customer> getAllCustomers() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<Customer> customersFromDB = new ArrayList<Customer>();
		customersFromDB = em.createNamedQuery("Customer.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return customersFromDB;
	}
	
	public Customer getCustomerByUsername(String name){
		EntityManager em = emf.createEntityManager();
		List<Customer> customers = (List<Customer>) 
				em.createNamedQuery("Customer.findByName").
				setParameter("name", name).getResultList();
		em.close();
		//Do whatever you want with the subscriber(s) with that username
		//Here we just return the first one
		Customer cus = new Customer();
		for(Customer c: customers) {
			cus = c;
		}
		return cus;
	}
}
