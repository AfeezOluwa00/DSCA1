package dao;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import entities.Loan;


@Path("/LoanSerDAO")
public class LoanSerDAO {
	
	private static Map<String, Loan> loan= new HashMap<String, Loan>();
	
	static {
		
	       Loan loan1 = new Loan();
	       loan1.setId(1);
	       loan1.setDescription("Student Loans");
	       loan.put(loan1.getDescription(), loan1);

	       Loan loan2 = new Loan();
	       loan2.setId(2);
	       loan2.setDescription("Car Loans");
	       loan.put(loan2.getDescription(), loan2);

    }

	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }
	
	@GET
    @Path("/helloworld")
    @Produces("text/plain")
    public String helloWorld(){
        return "Hello World New";    
    }
	
	
	@GET
    @Path("/echo/{message}")
    @Produces("text/plain")
    public String echo(@PathParam("message")String message){
        return message;  
    }
	
	
	@GET
    @Path("/loans")
    @Produces("application/xml")
    public List<Loan> listEmployees(){
        return new ArrayList<Loan>(loan.values());
    }
	
	@GET
    @Path("/loan/{loanid}")
    @Produces("application/xml")
    public Loan getEmployee(@PathParam("loanid")String loanid){
		return loan.get(loanid);		
    }
	
	@POST
	@Path("/createxml")
    @Consumes("application/xml")
    public String addEmployee(Loan loan) {
		return "Loan Amount " +loan.getDescription();		
    }
	
	@POST
	@Path("/createjson")
    @Consumes("application/json")
    public String addJSONEmployee(Loan loan){
		return "Loan Amount  " +loan.getDescription();		
    }
	
	@GET
    @Path("/json/loans/")
    @Produces("application/json")
    public List<Loan> listLoanJSON(){
		return new ArrayList<Loan>(loan.values());
    }

	@GET
    @Path("/json/loan/{loanid}")
    @Produces("application/json")
    public Loan getLoanDepositJSON(@PathParam("loanid")String loanid){
		return loan.get(loanid);		
    }
	

}

