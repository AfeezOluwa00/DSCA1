package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import entities.Customer;
import entities.Loan;
import entities.LoanDeposit;

public class LoanDepositDao {
	
	protected static EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("AfeezPu"); 	
	
	public LoanDepositDao() {
		
	}
	
	public void persist(LoanDeposit loanDeposit) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(loanDeposit);
		em.getTransaction().commit();
		em.close();
	}
	
	public void remove(LoanDeposit loanDeposit) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(loanDeposit));
		em.getTransaction().commit();
		em.close();
	}
	
	public LoanDeposit merge(LoanDeposit LoanDeposit) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		LoanDeposit updatedLoanDeposit = em.merge(LoanDeposit);
		em.getTransaction().commit();
		em.close();
		return updatedLoanDeposit;
	}
	
	public List<LoanDeposit> getAllLoanDeposits() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<LoanDeposit> loanDepositsFromDB = new ArrayList<LoanDeposit>();
		loanDepositsFromDB = em.createNamedQuery("LoanDeposit.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return loanDepositsFromDB;
	}
	
	
	
	public LoanDeposit getLoanDepositByID(String id){
		EntityManager em = emf.createEntityManager();
		List<LoanDeposit> loanDeposits = (List<LoanDeposit>) 
				em.createNamedQuery("LoanDeposit.findById").
				setParameter("id", id).getResultList();
		em.close();
		//Do whatever you want with the subscriber(s) with that username
		//Here we just return the first one
		LoanDeposit cus = new LoanDeposit();
		for(LoanDeposit c: loanDeposits) {
			cus = c;
		}
		return cus;
	}


}
