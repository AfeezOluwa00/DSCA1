package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entities.Customer;
import entities.Loan;
import entities.LoanDeposit;

public class LoanDao {
	
	protected static EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("AfeezPu"); 	
	
	public LoanDao() {
		
	}
	
	public void persist(Loan loan) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(loan);
		em.getTransaction().commit();
		em.close();
	}
	
	public void remove(Loan loan) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(loan));
		em.getTransaction().commit();
		em.close();
	}
	
	public Loan merge(Loan loan) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Loan updatedLoan = em.merge(loan);
		em.getTransaction().commit();
		em.close();
		return updatedLoan;
	}
	

	public List<Loan> getAllLoans() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<Loan> loansFromDB = new ArrayList<Loan>();
		loansFromDB = em.createNamedQuery("Loan.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return loansFromDB;
	}
	
	public Loan getLoanById(String id){
		EntityManager em = emf.createEntityManager();
		List<Loan> loans = (List<Loan>) 
				em.createNamedQuery("Loan.findById").
				setParameter("id", id).getResultList();
		em.close();
		//Do whatever you want with the subscriber(s) with that username
		//Here we just return the first one
		Loan cus = new Loan();
		for(Loan l: loans) {
			cus = l;
		}
		return cus;
	}


}
