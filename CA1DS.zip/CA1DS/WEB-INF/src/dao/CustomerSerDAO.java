package dao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import dao.CustomerDao;
import entities.Customer;

@Path("/CustomerSerDAO")
public class CustomerSerDAO {
	
	private static Map<String, Customer> customers = new HashMap<String, Customer>();
	
	static {
		
        Customer customer1 = new Customer();
        customer1.setId(1);
        customer1.setName("Fabrizio");
        customer1.setPhoneNo("Software Engineer");
        customer1.setAddress("1 The Lane");
        customers.put(customer1.getName(), customer1);
        
        Customer customer2 = new Customer();
        customer2.setId(3);
        customer2.setName("Afeez");
        customer2.setPhoneNo("Technican");
        customer2.setAddress("2 The Lane");
        customers.put(customer2.getName(), customer2);
        
    }

	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }
	
	@GET
    @Path("/helloworld")
    @Produces("text/plain")
    public String helloWorld(){
        return "Hello World New";    
    }
	
	
	@GET
    @Path("/echo/{message}")
    @Produces("text/plain")
    public String echo(@PathParam("message")String message){
        return message;  
    }
	
	
	@GET
    @Path("/customers")
    @Produces("application/xml")
    public List<Customer> listCustomers(){
        return new ArrayList<Customer>(customers.values());
    }
	
	@GET
    @Path("/customer/{customerid}")
    @Produces("application/xml")
    public Customer getCustomer(@PathParam("customerid")String customerId){
		return customers.get(customerId);		
    }
	
	@POST
	@Path("/createxml")
    @Consumes("application/xml")
    public String addCustomer(Customer customer) {
		return "Customer added " +customer.getName();		
    }
	
	@POST
	@Path("/createjson")
    @Consumes("application/json")
    public String addJSONCustomer(Customer customer){
		return "Customer addded " +customer.getName();		
    }
	
	@GET
    @Path("/json/customers/")
    @Produces("application/json")
    public List<Customer> listCustomersJSON(){
		return new ArrayList<Customer>(customers.values());
    }

	@GET
    @Path("/json/customer/{customerid}")
    @Produces("application/json")
    public Customer getCustomerJSON(@PathParam("customerid")String customerId){
		return customers.get(customerId);		
    }
	

}



