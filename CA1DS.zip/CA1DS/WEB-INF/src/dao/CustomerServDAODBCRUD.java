package dao;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import dao.CustomerDao;
import entities.Customer;



@Path("/CustomerServDAODBCRUD")
public class CustomerServDAODBCRUD {
	
		private static Map<String, Customer> customers = new HashMap<String, Customer>();
		
		static {
			
	        Customer customer1 = new Customer();
	        customer1.setId(1);
	        customer1.setName("Fabrizio");
	        customer1.setPhoneNo("Software Engineer");
	        customer1.setAddress("1 The Lane");
	        customers.put(customer1.getName(), customer1);
	        
	        Customer customer2 = new Customer();
	        customer2.setId(3);
	        customer2.setName("Afeez");
	        customer2.setPhoneNo("Technican");
	        customer2.setAddress("2 The Lane");
	        customers.put(customer2.getName(), customer2);
	        
	    }


	@GET
   @Path("/hello")
   @Produces("text/plain")
   public String hello(){
       return "Hello World";    
   }
	
	@GET
   @Path("/helloworld")
   @Produces("text/plain")
   public String helloWorld(){
       return "Hello World New";    
   }
	
	@GET
   @Path("/echo/{message}")
   @Produces("text/plain")
   public String echo(@PathParam("message")String message){
       return message;  
   }
	
	@GET
   @Path("/newEcho/{message}")
   @Produces("text/plain")
   public String newEcho(@PathParam("message")String message){
       return message;  
   }

	
	@GET
   @Path("/customers")
   @Produces("application/xml")
   public List<Customer> listCustomer(){
       return new ArrayList<Customer>(customers.values());
   }
	
	@GET
   @Path("/customer/{customerid}")
   @Produces("application/xml")
   public Customer getCustomers(@PathParam("customerid")String customerid){
		return customers.get(customerid);
	}
   
	
	@POST
	@Path("/createxml")
   @Consumes("application/xml")
   public String addCustomer(Customer customers){
		
		return "Customer added " +customers.getName();		
   }
	
	@POST
	@Path("/createjson")
   @Consumes("application/json")
   public String addJSONCustomer(Customer customers){
		return "Customer added " +customers.getName();		
   }
	
	@GET
   @Path("/json/customers/")
   @Produces("application/json")
   public List<Customer> listCustomersJSON(){
		return new ArrayList<Customer>(customers.values());
   }

	@GET
   @Path("/json/customer/{customerid}")
   @Produces("application/json")
   public Customer getCustomerJSON(@PathParam("customerid")String customerid){
		return customers.get(customerid);		
   }
	
	@GET
   @Path("/customersxmlfromdb")
   @Produces("application/xml")
   public List<Customer> getCustomerFromDB(){
       CustomerDao dao = new CustomerDao();
       return dao.getAllCustomers();
   }
	
	@GET
   @Path("/customersjsonfromdb")
   @Produces("application/json")
   public List<Customer> getJSONCustomersFromDB(){
       CustomerDao dao = new CustomerDao();
       return dao.getAllCustomers();
   }
	
	@GET
   @Path("/jsonDB/customer/{CustomerName}")
   @Produces("application/json")
   public Customer getCustomerByNameFromDBJSON(@PathParam("CustomerName")String CustomerName){
		CustomerDao dao = new CustomerDao();
		return dao.getCustomerByUsername(CustomerName);		
   }
	
	@GET
   @Path("/customerfromDBXML/{employeeName}")
   @Produces("application/xml")
   public Customer getCustomerByNameFromDBXML(@PathParam("CustomerName")String CustomerName){
		CustomerDao dao = new CustomerDao();
		return dao.getCustomerByUsername(CustomerName);	
   }
	
	@POST
	@Path("/newCustomer")
   @Consumes("application/json")
   public String addCustomerToDBJSON(Customer customer){
		CustomerDao dao = new CustomerDao();
		dao.persist(customer);
		return "Customer added to DB from JSON Param "+customer.getName();	
   }
	
	@PUT
   @Path("/updateCustomer/")
   @Produces("application/json")
   public Customer updateCustomer(Customer customer){
		CustomerDao dao = new CustomerDao();
		return dao.merge(customer);	
   }
	
	@DELETE
   @Path("/deleteCustomer/{CustomerName}")
   @Produces("text/plain")
   public String deleteCustomer(@PathParam("CustomerName")String CustomerName){
		CustomerDao dao = new CustomerDao();
		Customer cus = dao.getCustomerByUsername(CustomerName);
		dao.remove(cus);	
		return "Customer "+cus+" deleted";
   }
	
	
}

