package dao;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;


import dao.LoanDao;
import entities.Loan;



@Path("/LoanServDAODBCRUD")
public class LoanServDAODBCRUD {
	
		private static Map<String, Loan> loans = new HashMap<String, Loan>();
		
		static {
			
			Loan loan1 = new Loan();
			loan1.setId(1);
			loan1.setDescription("Student Loan");
	        loans.put(loan1.getDescription(), loan1);
	        

			Loan loan2= new Loan();
			loan2.setId(1);
			loan2.setDescription("Car Loan");
	        loans.put(loan1.getDescription(), loan2);
	    }


	@GET
   @Path("/hello")
   @Produces("text/plain")
   public String hello(){
       return "Hello World";    
   }
	
	@GET
   @Path("/helloworld")
   @Produces("text/plain")
   public String helloWorld(){
       return "Hello World New";    
   }
	
	@GET
   @Path("/echo/{message}")
   @Produces("text/plain")
   public String echo(@PathParam("message")String message){
       return message;  
   }
	
	@GET
   @Path("/newEcho/{message}")
   @Produces("text/plain")
   public String newEcho(@PathParam("message")String message){
       return message;  
   }

	
	@GET
   @Path("/loan")
   @Produces("application/xml")
   public List<Loan> listLoanDeposit(){
       return new ArrayList<Loan>(loans.values());
   }
	
	@GET
   @Path("/loan/{loanid}")
   @Produces("application/xml")
   public Loan getLoan(@PathParam("loanid")String loanid){
		return loans.get(loanid);
	}
   
	
	@POST
	@Path("/createxml")
   @Consumes("application/xml")
   public String addLoan(Loan loans){
		
		return "Loan Deposit added " +loans.getId();		
   }
	
	@POST
	@Path("/createjson")
   @Consumes("application/json")
   public String addJSONLoanDeposit(Loan loans){
		return "Loan added " +loans.getId();		
   }
	
	@GET
   @Path("/json/loan/")
   @Produces("application/json")
   public List<Loan> listLoanJSON(){
		return new ArrayList<Loan>(loans.values());
   }

	@GET
   @Path("/json/loan/{loanid}")
   @Produces("application/json")
   public Loan getLoanJSON(@PathParam("loanid")String loanid){
		return loans.get(loanid);		
   }
	
	@GET
   @Path("/loansxmlfromdb")
   @Produces("application/xml")
   public List<Loan> getLoanFromDB(){
		LoanDao dao = new LoanDao();
       return dao.getAllLoans();
   }
	
	@GET
   @Path("/loanjsonfromdb")
   @Produces("application/json")
   public List<Loan> getJSONLoanFromDB(){
		LoanDao dao = new LoanDao();
       return dao.getAllLoans();
   }
	

	@GET
    @Path("/jsonDB/loan/{loanID}")
    @Produces("application/json")
    public Loan getLoanIDFromDBJSON(@PathParam("loanId")String LoanID){
		LoanDao dao = new LoanDao();
		return dao.getLoanById(LoanID);		
    }
	
	@GET
   @Path("/loanfromDBXML/{LoanID}")
   @Produces("application/xml")
   public Loan getLoanByIDFromDBXML(@PathParam("Loan ID")String LoanID){
		LoanDao dao = new LoanDao();
		return dao.getLoanById(LoanID);	
   }
	
	@POST
	@Path("/newLoan")
   @Consumes("application/json")
   public String addLoanToDBJSON(Loan loans){
		LoanDao dao = new LoanDao();
		dao.persist(loans);
		return "Loan  added to DB from JSON Param "+loans.getId();	
   }
	
	@PUT
   @Path("/updateLoan/")
   @Produces("application/json")
   public Loan updateLoanDeposit(Loan loans){
		LoanDao dao = new LoanDao();
		return dao.merge(loans);	
   }
	
	@DELETE
   @Path("/deleteLoan/{LoanName")
   @Produces("text/plain")
   public String deleteLoan(@PathParam("LoanName")String LoanName){
		LoanDao dao = new LoanDao();
		Loan cus = dao.getLoanById(LoanName);
		dao.remove(cus);	
		return "Loan "+cus+" deleted";
   }
	
	
}

