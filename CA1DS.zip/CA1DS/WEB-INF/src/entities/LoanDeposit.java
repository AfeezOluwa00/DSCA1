package entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "loanDeposit")
@Entity
public class LoanDeposit {
		
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String depositAmount;
	private String depositDate;

	
	public LoanDeposit() {

	}
	

	public LoanDeposit(String depositAmount , String depositDate) {
		this.depositAmount = depositAmount;
		this.depositDate = depositDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}
	public String getDepositDate() {
		return depositDate;
	}

	public void setDepositDate(String depositDate) {
		this.depositDate = depositDate;
	}
	
	

}
