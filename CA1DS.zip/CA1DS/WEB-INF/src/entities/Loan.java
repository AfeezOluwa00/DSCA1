package entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "loan")
@Entity
public class Loan {
		
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private String description;


	@OneToMany(fetch = FetchType.EAGER)
	private List<LoanDeposit> loanDeposits = new ArrayList<LoanDeposit>();
	
	public Loan() {

	}

	
	public Loan(String description, List<LoanDeposit> loanDepsoits) {
		super();
		this.description = description;
		this.loanDeposits = loanDeposits;
	}
	
	
	public Loan(String description) {
		this.description = description;
	}

	public void addLoanDeposit(LoanDeposit loanDeposit) {
		loanDeposits.add(loanDeposit);
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}

	


	public List<LoanDeposit> getLoanDeposit() {
		return loanDeposits;
	}



	public void setLoanDeposit(List<LoanDeposit> loanDeposits) {
		this.loanDeposits = loanDeposits;
	}

	
	

}