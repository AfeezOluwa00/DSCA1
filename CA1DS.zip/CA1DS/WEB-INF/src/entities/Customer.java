package entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries({
	@NamedQuery(name="Customer.findAll", query="select o from Customer o"), 
	@NamedQuery(name = "Customer.findByName", query = "select o from Customer o where o.name=:name")
})

@XmlRootElement(name = "customer")
@Entity
public class Customer {
		
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name;
	private String phoneNo;
	private String address;
	private String annualSal;
	@OneToOne
	private Loan loan;

	public Customer() {

	}
	
	public Customer(String name, String phoneNo, String address , String annualSal ,Loan loan) {
		this.name = name;
		this.phoneNo = phoneNo;
		this.loan = loan;
		this.address = address;
		this.annualSal = annualSal;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getAnnualSal() {
		return annualSal;
	}

	public void setAnnualSal(String annualSal) {
		this.annualSal = annualSal;
	}
	
	
	
	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}
	
	

}
